# thp_jour_9
Projet validant Ruby "s'entrainer sur les boucles"
travail en pair-programming Emeric, Debora
